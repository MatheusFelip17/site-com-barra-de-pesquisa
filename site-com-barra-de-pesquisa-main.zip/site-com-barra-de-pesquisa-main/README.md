# site com barra de pesquisa
site com barra de pesquisa que leva a player cards (não é todo tipo de pesquisa, só para levar a player cards)
